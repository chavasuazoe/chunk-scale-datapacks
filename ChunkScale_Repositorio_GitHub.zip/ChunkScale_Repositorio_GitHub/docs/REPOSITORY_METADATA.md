# Metadatos recomendados para GitHub

## Identidad

- **Nombre visible:** Chunk Scale
- **Slug recomendado:** `chunk-scale-datapack`
- **Alternativa corta:** `chunk-scale`
- **Descripción corta:** Datapack para Minecraft Java que asigna una escala determinista a cada chunk y redimensiona jugadores y entidades vivas al cruzar sus límites.
- **Visibilidad sugerida:** Pública, únicamente si el titular desea compartir el código.
- **Rama principal:** `main`

## Clasificación

- **Producto:** Minecraft: Java Edition
- **Tipo:** Data Pack
- **Loader:** Vanilla / ninguno
- **Lado:** Servidor; en un jugador lo ejecuta el servidor integrado
- **Lenguajes:** MCFunction, JSON y Markdown
- **Namespace:** `chunk_scale`
- **Dependencias:** Ninguna
- **Cliente requerido:** Vanilla compatible con la versión del servidor
- **Bedrock Edition:** No compatible

## Compatibilidad publicada

- **Minecraft mínimo:** 26.3 Snapshot 4
- **Minecraft máximo:** 26.3 Snapshot 4
- **Data Pack format mínimo:** 111.0
- **Data Pack format máximo:** 111.0
- **Snapshot 3:** No declarada; usa formato 110.0
- **Snapshot 5:** No declarada; usa formato 112.0
- **26.3 estable:** Sin confirmar hasta que exista y se pruebe

## Release inicial

- **Versión de proyecto:** `0.1.0`
- **Tag:** `v0.1.0-mc26.3-snapshot4`
- **Título:** `Chunk Scale v0.1.0 — Minecraft 26.3 Snapshot 4`
- **Nombre del archivo:** `ChunkScale_v0.1.0_MC26.3-Snapshot4.zip`
- **Marcar como pre-release:** Sí, porque depende de una snapshot de Minecraft

## Topics sugeridos

```text
minecraft
minecraft-java
minecraft-datapack
datapack
mcfunction
vanilla
entity-scaling
chunk-based
snapshot
multiplayer
```

## Texto para “About”

```text
Datapack para Minecraft Java que asigna una escala determinista a cada chunk y redimensiona jugadores y entidades vivas al cruzar sus límites.
```

## Redes y catálogos

Para publicar también en Modrinth o Planet Minecraft, usa la misma compatibilidad exacta y marca el proyecto como datapack para Java Edition. No indiques soporte para Snapshot 5 o 26.3 final sin una prueba independiente.

## Licencia

- **Recomendación si eres autor y quieres código abierto permisivo:** MIT.
- **Recomendación si todavía no decides permisos:** no añadir licencia por ahora.
- **Importante:** un repositorio público sin licencia permite ver el código, pero no concede automáticamente permiso para copiarlo, modificarlo o redistribuirlo.

# Auditoría técnica del archivo recibido

## Resumen

El archivo recibido es un datapack moderno de Minecraft Java. Su estructura es válida y contiene `pack.mcmeta` en la raíz, tags de carga/tick y funciones bajo el namespace `chunk_scale`.

## Validaciones estáticas realizadas

- El ZIP se puede abrir correctamente.
- No contiene ejecutables, enlaces simbólicos ni archivos binarios sospechosos.
- `pack.mcmeta`, `load.json` y `tick.json` son JSON válido.
- El datapack declara `min_format: [111, 0]` y `max_format: [111, 0]`.
- El formato 111.0 corresponde a Minecraft Java 26.3 Snapshot 4.
- SHA-256 del archivo original: `a3b940a95ddbf7b185f89dc30d03ca86d75edcb2161001a584ef3d5a67fa7844`.

## Compatibilidad

### Confirmada por metadatos

- Minecraft Java 26.3 Snapshot 4.
- Data Pack format 111.0.

### No declarada

- Snapshot 3 usa formato 110.0.
- Snapshot 5 usa formato 112.0.
- El código no utiliza los cambios específicos anunciados para Snapshot 5, por lo que una adaptación podría ser sencilla, pero debe cambiarse el rango del pack y realizarse una prueba real antes de publicarla.

## Hallazgos

### 1. Compatibilidad demasiado estricta

El pack está limitado exactamente a 111.0. Es correcto para una release específica, pero cada nueva snapshot necesitará una revisión y posiblemente una nueva release.

### 2. Mensaje de carga potencialmente engañoso

`load.mcfunction` siempre informa que el primer jugador fijará el origen, aunque el scoreboard pueda conservar un origen configurado previamente.

### 3. Desinstalación incompleta

`reset_scales` solo restaura entidades actualmente cargadas. Entidades descargadas pueden conservar su atributo modificado hasta que sean procesadas de nuevo. Además, no se eliminan objetivos de scoreboard ni el storage del datapack.

### 4. Coste por tick

Cada tick se procesan todos los jugadores y entidades vivas cargadas. Se realizan dos lecturas NBT de posición por entidad y comparaciones de scoreboard. La escala solo se recalcula al cambiar de chunk, pero el sondeo sigue siendo lineal respecto al número de entidades cargadas.

### 5. Descarga de GitHub

El ZIP automático “Source code” de GitHub añade una carpeta exterior. Para que el usuario pueda copiar el ZIP directamente a `datapacks/`, debe adjuntarse como asset una compilación donde `pack.mcmeta` y `data/` estén en la raíz.

### 6. Documentación/licencia

El archivo incluía un README en texto plano, pero no los archivos habituales de un repositorio: `README.md`, `CHANGELOG.md`, instrucciones de contribución, workflow de empaquetado y licencia definida.

## Recomendaciones antes de una versión 1.0.0

1. Añadir `chunk_scale:uninstall` para restaurar entidades cargadas, eliminar objetivos y borrar storage.
2. Mostrar mensajes diferentes según exista o no un origen.
3. Crear pruebas reproducibles para coordenadas negativas y cambios de dimensión.
4. Medir MSPT/TPS con 100, 500 y 1,000 entidades cargadas.
5. Publicar una release por cada formato de datapack probado.
6. Añadir un icono `pack.png` original y conforme a las reglas de marca.
7. Elegir licencia solo después de confirmar titularidad.

## Alcance de la auditoría

La revisión fue estática. No se pudo ejecutar el servidor oficial dentro del entorno de análisis, por lo que la compatibilidad en juego debe verificarse antes de marcar una release como plenamente probada.

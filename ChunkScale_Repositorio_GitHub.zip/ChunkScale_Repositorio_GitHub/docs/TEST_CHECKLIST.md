# Lista de pruebas para una release

## Carga

- [ ] El ZIP contiene `pack.mcmeta` en la raíz.
- [ ] `/datapack list enabled` muestra el pack.
- [ ] `/reload` no produce errores.
- [ ] Los objetivos `cs_*` se crean una sola vez.

## Origen

- [ ] El primer jugador fija el origen automáticamente.
- [ ] El chunk de origen usa 1.00×.
- [ ] `/function chunk_scale:set_origin` cambia el origen.
- [ ] Las entidades cargadas recalculan su escala tras cambiar el origen.

## Coordenadas

- [ ] X positiva.
- [ ] X negativa.
- [ ] Z positiva.
- [ ] Z negativa.
- [ ] Cruce en los límites -1/0 y 15/16.
- [ ] Los cuatro vecinos cardinales difieren del chunk actual.

## Entidades

- [ ] Jugador.
- [ ] Zombie u otro mob hostil.
- [ ] Animal pasivo.
- [ ] Shulker a escala enorme.
- [ ] Mannequin/armor stand cuando corresponda.
- [ ] Ender Dragon excluido.
- [ ] Objetos, flechas, barcos y minecarts no afectados.

## Multijugador

- [ ] Dos jugadores en chunks con escalas distintas.
- [ ] Entrada y salida de jugadores.
- [ ] Cambio de dimensión.
- [ ] Reinicio del servidor conserva el origen.

## Rendimiento

- [ ] 100 entidades cargadas.
- [ ] 500 entidades cargadas.
- [ ] 1,000 entidades cargadas.
- [ ] Comparar MSPT con y sin el datapack.

## Desinstalación

- [ ] Ejecutar `reset_scales` antes de retirar el pack.
- [ ] Verificar entidades cargadas.
- [ ] Revisar objetivos y storage residuales.

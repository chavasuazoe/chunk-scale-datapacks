attribute @s minecraft:scale base set 3.0
execute if entity @s[type=minecraft:player] run title @s actionbar {"type":"text","text":"Chunk: escala ENORME (3.00×)","color":"red","bold":true}

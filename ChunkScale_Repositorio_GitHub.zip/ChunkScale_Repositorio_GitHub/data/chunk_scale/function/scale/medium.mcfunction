attribute @s minecraft:scale base set 0.75
execute if entity @s[type=minecraft:player] run title @s actionbar {"type":"text","text":"Chunk: escala MEDIANA (0.75×)","color":"yellow"}

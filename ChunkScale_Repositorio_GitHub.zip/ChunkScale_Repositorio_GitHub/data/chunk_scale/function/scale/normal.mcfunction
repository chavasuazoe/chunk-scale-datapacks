attribute @s minecraft:scale base set 1.0
execute if entity @s[type=minecraft:player] run title @s actionbar {"type":"text","text":"Chunk: escala NORMAL (1.00×)","color":"green"}

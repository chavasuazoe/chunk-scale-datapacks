attribute @s minecraft:scale base set 1.5
execute if entity @s[type=minecraft:player] run title @s actionbar {"type":"text","text":"Chunk: escala GRANDE (1.50×)","color":"gold"}

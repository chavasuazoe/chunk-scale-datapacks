attribute @s minecraft:scale base set 0.4
execute if entity @s[type=minecraft:player] run title @s actionbar {"type":"text","text":"Chunk: escala PEQUEÑA (0.40×)","color":"aqua"}

# Chunk Scale — inicialización sin errores al usar /reload.
execute unless data storage chunk_scale:state installed run function chunk_scale:setup

scoreboard players set $two cs_const 2
scoreboard players set $five cs_const 5
execute unless score $origin_set cs_global matches 1 run scoreboard players set $origin_set cs_global 0

tellraw @a {"type":"text","text":"[Chunk Scale] ","color":"gold","bold":true,"extra":[{"type":"text","text":"Datapack cargado. El primer jugador fijará el chunk de origen.","color":"yellow","bold":false}]}

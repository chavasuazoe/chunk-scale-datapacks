# Restaura la escala normal de todas las entidades vivas actualmente cargadas.
execute as @a run attribute @s minecraft:scale base reset
execute as @e[type=!minecraft:player,type=!minecraft:ender_dragon] if data entity @s Health run attribute @s minecraft:scale base reset
scoreboard players reset @e cs_px
scoreboard players reset @e cs_pz
tellraw @a {"type":"text","text":"[Chunk Scale] ","color":"gold","bold":true,"extra":[{"type":"text","text":"Escalas restauradas; volverán a aplicarse al siguiente tick.","color":"yellow","bold":false}]}

# Posición / 16 y redondeada hacia abajo = coordenada exacta del chunk,
# incluyendo coordenadas negativas.
execute store result score @s cs_x run data get entity @s Pos[0] 0.0625
execute store result score @s cs_z run data get entity @s Pos[2] 0.0625

# Recalcular únicamente al entrar en otro chunk o al procesarse por primera vez.
execute unless score @s cs_x = @s cs_px run function chunk_scale:entity/apply
execute if score @s cs_x = @s cs_px unless score @s cs_z = @s cs_pz run function chunk_scale:entity/apply

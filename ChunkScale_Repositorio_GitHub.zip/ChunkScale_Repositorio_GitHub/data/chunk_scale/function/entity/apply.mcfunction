# Patrón determinista: índice = (chunkX-origenX) + 2*(chunkZ-origenZ), módulo 5.
# El origen produce 0 (escala normal) y ningún vecino ortogonal comparte índice.
scoreboard players operation @s cs_tmp = @s cs_x
scoreboard players operation @s cs_tmp -= $origin_x cs_global

scoreboard players operation $work_z cs_global = @s cs_z
scoreboard players operation $work_z cs_global -= $origin_z cs_global
scoreboard players operation $work_z cs_global *= $two cs_const
scoreboard players operation @s cs_tmp += $work_z cs_global
scoreboard players operation @s cs_tmp %= $five cs_const
execute if score @s cs_tmp matches ..-1 run scoreboard players add @s cs_tmp 5

execute if score @s cs_tmp matches 0 run function chunk_scale:scale/normal
execute if score @s cs_tmp matches 1 run function chunk_scale:scale/tiny
execute if score @s cs_tmp matches 2 run function chunk_scale:scale/medium
execute if score @s cs_tmp matches 3 run function chunk_scale:scale/large
execute if score @s cs_tmp matches 4 run function chunk_scale:scale/huge

scoreboard players operation @s cs_px = @s cs_x
scoreboard players operation @s cs_pz = @s cs_z

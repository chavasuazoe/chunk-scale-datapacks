# El primer jugador conectado fija automáticamente el origen.
execute if score $origin_set cs_global matches 0 as @a[limit=1,sort=arbitrary] at @s run function chunk_scale:origin/capture

# Jugadores: siempre incluidos.
execute if score $origin_set cs_global matches 1 as @a at @s run function chunk_scale:entity/tick

# Otras entidades vivas. El dragón está excluido porque no admite minecraft:scale.
execute if score $origin_set cs_global matches 1 as @e[type=!minecraft:player,type=!minecraft:ender_dragon] at @s if data entity @s Health run function chunk_scale:entity/tick

# Debe ejecutarse como un jugador y en su posición.
execute store result score $origin_x cs_global run data get entity @s Pos[0] 0.0625
execute store result score $origin_z cs_global run data get entity @s Pos[2] 0.0625
scoreboard players set $origin_set cs_global 1

# Fuerza que todas las entidades cargadas vuelvan a calcular su escala.
scoreboard players reset @e cs_px
scoreboard players reset @e cs_pz

tellraw @a {"type":"text","text":"[Chunk Scale] ","color":"gold","bold":true,"extra":[{"type":"text","text":"Origen fijado en el chunk X=","color":"yellow","bold":false},{"type":"score","score":{"name":"$origin_x","objective":"cs_global"},"color":"white"},{"type":"text","text":", Z=","color":"yellow"},{"type":"score","score":{"name":"$origin_z","objective":"cs_global"},"color":"white"},{"type":"text","text":". Este chunk usa escala normal.","color":"yellow"}]}

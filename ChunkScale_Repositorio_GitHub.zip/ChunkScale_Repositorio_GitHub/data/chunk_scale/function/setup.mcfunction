# Se ejecuta una sola vez por mundo.
scoreboard objectives add cs_x dummy
scoreboard objectives add cs_z dummy
scoreboard objectives add cs_px dummy
scoreboard objectives add cs_pz dummy
scoreboard objectives add cs_tmp dummy
scoreboard objectives add cs_const dummy
scoreboard objectives add cs_global dummy

data modify storage chunk_scale:state installed set value 1b

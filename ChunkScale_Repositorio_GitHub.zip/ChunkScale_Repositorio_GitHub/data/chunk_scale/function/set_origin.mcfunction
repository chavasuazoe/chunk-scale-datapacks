# Función pública. Úsala estando en el chunk que deseas convertir en origen:
# /function chunk_scale:set_origin
execute as @p[limit=1,sort=nearest] at @s run function chunk_scale:origin/capture
